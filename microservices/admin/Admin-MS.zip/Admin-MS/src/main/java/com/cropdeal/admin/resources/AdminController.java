package com.cropdeal.admin.resources;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
	
	@RequestMapping("/admin")
	public String check()
	{
		return "Hello-World-Admin";
	}

}
